<?php
get_header();
?>
<main id="site-content" class="site-main">
    <?php get_template_part('template-parts/sections/hero'); ?>
    <?php get_template_part('template-parts/sections/events'); ?>
    <?php get_template_part('template-parts/sections/membership-ctas'); ?>
    <?php get_template_part('template-parts/sections/working-groups'); ?>
    <?php get_template_part('template-parts/sections/group-photo'); ?>

    <?php if ('page' === get_option('show_on_front') && have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <?php if (trim((string) get_the_content()) !== '') : ?>
                <section class="page-content-block">
                    <div class="site-container prose-block">
                        <?php the_content(); ?>
                    </div>
                </section>
            <?php endif; ?>
        <?php endwhile; ?>
    <?php endif; ?>
</main>
<?php
get_footer();
